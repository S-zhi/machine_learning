function sigmoid(x){
	s = 1/(1+Math.exp(-x))
	return s
}